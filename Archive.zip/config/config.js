module.exports = {
    // aws_local_config: {
    //     region: 'local',
    //     endpoint: 'http://localhost:3000'
    // },
    aws_remote_config: {
        accessKeyId: process.env.AccessKey,
        secretAccessKey: process.env.SecretAccessKey,
        region: 'us-east-2',
    }
};